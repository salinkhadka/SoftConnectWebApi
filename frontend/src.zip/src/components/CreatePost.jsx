import React from 'react'
import AddPostComponent from './Admin/AddPost'

export default function CreatePost() {
  return (
    <AddPostComponent/>
  )
}
