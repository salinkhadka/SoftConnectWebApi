import React from 'react'
import RegisterForm from '../components/SignupComponent'
// import './SignupComponent.css';

function SignupPage() {
  return (
    <div><RegisterForm/></div>
  )
}

export default SignupPage